export const securityKeys = [
  'received-spm',
  'authentication-results',
  'dkim-signature',
  'arc-authentication-results'
]

export const basicKeys = ['cc', 'date', 'from', 'message-id', 'received', 'subject', 'to']
