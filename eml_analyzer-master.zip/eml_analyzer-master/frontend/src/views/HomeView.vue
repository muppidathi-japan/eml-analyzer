<script setup lang="ts">
import Upload from '@/components/UploadItem.vue'
</script>

<template>
  <Upload />
</template>
