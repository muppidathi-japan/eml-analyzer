<script setup lang="ts">
import Cache from '@/components/CacheItem.vue'
</script>

<template>
  <Cache />
</template>
