<template>
  <div class="flex w-full flex-col">
    <div class="divider"></div>
  </div>
</template>
