<template>
  <div class="flex justify-center items-center mt-4 mb-4">
    <span class="loading loading-spinner loading-xl"></span>
  </div>
</template>
